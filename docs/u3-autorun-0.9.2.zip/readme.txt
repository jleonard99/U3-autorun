****************************************************************************
u3-autorun.exe
Freeware u3-launchad replacement

v0.9.2
****************************************************************************

Date: Tue 10/17/2006

I. Description

	u3-autorun replaces the proprietary U3-Launchpad included by default
	on all U3-enabled flash drives.  Rather than using a cumbersome flash
	loader and ugly, unchangable menu, u3-autorun spawns a copy of
	itself to your hard drive and scans your flash drive for an ini file
	containing information about the program you want to run.  Finding
	this file, it reads the program information from it, and runs the
	file.  Optionally, it can wait for your file to	finish running and
	eject the drive when it is done.  When it has completed execution,
	the spawned copy will delete itself.

	When used with a portable menu software (such as Pegstop's PStart),
	you can effectively duplicate the functionality of the U3-Launchpad
	yourself, using	entirely free software of your own choice.

	Since the interface for flashing the U3 partition is still poorly
	understood, this iso file can only be successfully flashed to cruzer
	drives at this time.  This is because the LPInstaller.exe and its
	associated exploit are only available for Cruzer drives.
	
	Once the process has been reverse-engineered and is more thoroughly
	understood, a similiar process should apply to flash the iso to any
	other U3-enabled device.  The application should still perform
	identically. 


II. File List

-cruzer-autorun.iso
    o   u3-autorun.exe	- the main executable
    o	autorun.inf	- windows autorun file (only needed on the u3 partition)
    o   readme.txt   	- this file
    o   u3-autorun.ini.samp - sample u3-autorun.ini to be placed on the writable
			      partition of your flash drive



III. Requirements

    1.  Get ahold of LPInstaller.exe

    Because it is proprietary software, I cannot distribute the Cruzer
    U3 Launchpad installer with this freeware project, but you can probably
    find it fairly easily if you look for it.  At the time of this writing,
    you can still get it from sandisk at:

    http://u3.sandisk.com/download/apps/LPInstaller.exe



IV. Parameters (you needn't bother with these, but here they are)

    /a		  	run in autorun mode.  The program will spawn a copy
			of itself to a temporary location, and terminate.

    /d <driveletter>	Run in spawned mode.  If the eject option is
			specified, program will eject the drive specified
			by <driveletter> before termination


V. How to Use

        1.  Place the iso in the same directory as LPInstaller.exe

	2. Insert your flash drive into the machine.

	3. Run LPInstaller.exe in the same location as our modified iso

	4. Select the "Yes, run Launchpad ..." option from the menu

    LPInstaller.exe will check its current directory for suitable iso's to
    install to the U3 partition.  By ensuring that this iso is named
    cruzer-autorun.iso, and by selecting the "Yes, run Launchpad..." option
    in LPInstaller, it will override the default behavior of downloading the
    image, and install this one instead.


VI. History:

    Version 0.9.2 - Non-existent-exe bugfix
	-Minor bugfix.  It is possible that, if the .exe in the .ini doesn't
	 exist or doesn't spawn successfully, the drive will simply eject
	 moments after inserting it.  This problem has been addressed.

	-Added 1-second delay before eject.  Should stop a lot of "X:\ is not
	 available or has been moved" errors.

    Version 0.9.1 - Self-deletion bugfix.
	-Was calling CreateFile() with FILE_SHARE_READ, which made
	 the self-delete function problematic. Fixed this problem.

    Version 0.9 - First release



VII. Compatibility

    This tool has been tested under the following platforms:

        Windows 2000 Professional and Server
        Windows XP Home and Professional

    Further testing is necessary for older/legacy systems, but it should
    work on 95(with drivers)/98/ME systems.


VIII. Known Issues

    1) "There is no disk in the drive..."

    Under some configurations, the program may thrown an error about
    a disk not being in the drive.  This happens because u3-autorun is
    currently set to scan all drives tagged as DRIVE_REMOVABLE by Windows.
    Unfortunately, this also includes things like integrated memory stick
    readers and empty usb card reader drives and the like on media PCs.
    When it attempts to scan these drives, the error is thrown because they
    are empty.  The next version will address this either by using
    SetupDiGetDeviceRegistryProperty() to determine if the drive is USB or
    not, or by scanning only drive letters mapped to the same physical device
    as the one it is called from.  Currently testing this.



IX. Additional Resources

    The page that started it all:
	
	<http://cse.msstate.edu/~rwm8/hackingU3/>

    My inspiration (surely there was a better way!):

	<http://www.hak5.org/forums/viewtopic.php?p=31505>


X. Thanks

    Brodie Thiesfield <code@jellycan.com>
	
	For writing SimpleIni.h, which will make future functionality less
	of a pain in the ass to implement.

    Uwe Sieber <http://www.uwe-sieber.de>

	For the USB eject code.

XI. About Me

    I am Andy Walker.  I am 27, and I write teh s0ftware.

    You can contact me about this program by writing to:

    walkeraj+u3@gmail.com.