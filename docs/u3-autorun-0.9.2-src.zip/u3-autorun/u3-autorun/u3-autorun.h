#pragma once

#include "resource.h"
#include <stdio.h>
#include <Setupapi.h>
#include <winioctl.h>
#include <winioctl.h>
#include <cfgmgr32.h>
#include <shellapi.h>
