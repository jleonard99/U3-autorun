// u3-autorun.cpp : Generic, flexible autolauncher replacement for U3 drives.
// Main Code copy

#include "stdafx.h"
#include "u3-autorun.h"
#include "RemoveDriveByLetter.h"
#include "CmdLine.h"
#include "SelfDelete.h"
#include "SimpleIni.h"

#ifdef _DEBUG
	#include "ConStream.h"
	#include <iostream>	
#endif


//-----------------------------------

int APIENTRY WinMain(HINSTANCE hInstance,
					 HINSTANCE hPrevInstance,
					 LPSTR lpCmdLine,
					 int nCmdShow)
{	
	CCmdLine cmdLine;
	//If we're in debug mode, open the debugging console
	#ifdef _DEBUG
	ConStream debugwindow;	
	debugwindow.Open();
	debugwindow << "Beginning Debug Output\n\n";
	#endif		

	//Parse command line arguments.
	cmdLine.SplitLine (__argc, __argv);


	if (cmdLine.HasSwitch("-a")) //If we are the exe on the U3 Partition
	{
		CHAR szPathOrig[_MAX_PATH], szPathClone[_MAX_PATH];
		GetModuleFileName(NULL, szPathOrig, _MAX_PATH);
		GetTempPath(_MAX_PATH, szPathClone);
		GetTempFileName(szPathClone, __TEXT("Del"), 0, szPathClone);
		while(CopyFile(szPathOrig, szPathClone, FALSE) == 0) Sleep(1000);
		
		HANDLE hfile = CreateFile(szPathClone, 0, FILE_SHARE_DELETE, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);

	    CHAR szCmdLine[512];
		HANDLE hProcessOrig = OpenProcess(SYNCHRONIZE, TRUE, GetCurrentProcessId());
		//wsprintf(szCmdLine, __TEXT("%s %d \"%s\""), szPathClone, hProcessOrig, szPathOrig);
		wsprintf(szCmdLine, __TEXT("%s -d %c"), szPathClone, szPathOrig[0]);
		STARTUPINFO si;
		ZeroMemory(&si, sizeof(si));
		si.cb = sizeof(si);
		PROCESS_INFORMATION pi;		
		CreateProcess(NULL, szCmdLine, NULL, NULL, TRUE, DETACHED_PROCESS, NULL, "C:\\", &si, &pi);
		CloseHandle(hProcessOrig);
		CloseHandle(hfile);
		CloseHandle(pi.hThread);
		CloseHandle(pi.hProcess);
	}
	else if (cmdLine.HasSwitch("-d")) // if we have a -dX, that means we are the new process and originated on drive <X>:
	{	
		/*HANDLE hProcessOrig = (HANDLE) __argv[1];		
		WaitForSingleObject(hProcessOrig, INFINITE);
		CloseHandle(hProcessOrig);*/
		CSimpleIniA inifile;

		#ifdef _DEBUG
		debugwindow << "I am the new process!\n";
		debugwindow << "I received commandline: " << lpCmdLine << "\n";
		#endif
		
		//char DrvIni[256] = "d:\\";
		char DrvIni[256];
		char PathIni[256];
		bool eject=false;
		bool foundini = false;

		strcpy (DrvIni, &cmdLine.GetArgument("-d",0)[0]);
		strcat (DrvIni, ":\\");
		DrvIni[0]++;
		
		for ( ; DrvIni[0]<='z'; DrvIni[0]++)
		{
			//TODO: Better detection of usb drives.  Currently it will scan cdroms, too, and in some situations this will generate an error.
			if (GetDriveType(DrvIni)==DRIVE_REMOVABLE)
			{
				//cpy and catenate
				strcpy (PathIni, DrvIni);
				strcat (PathIni, "u3-autorun.ini");
				#ifdef _DEBUG
				debugwindow << "Looking for: " << PathIni << "\n";
				#endif				
				if (inifile.LoadFile(PathIni)==0)
				{
					foundini=true;
					break;
				}
			}			
		}
		#ifdef _DEBUG
		if (foundini) debugwindow << "Found u3-autorun.ini on: "<< DrvIni << "\n";
		else debugwindow <<"u3-autorun.ini not found! \n";
		#endif
		
		if (foundini)
		{			
			//Read from the ini file
			if (inifile.GetValue("u3-autorun", "exefile") != 0 ) strcat (DrvIni, inifile.GetValue("u3-autorun", "exefile"));
			eject = strcmp(inifile.GetValue("u3-autorun", "eject"),"false");
			#ifdef _DEBUG
			debugwindow<<"DrvIni is: "<<DrvIni<< "\n";
			debugwindow<<"Eject is: "<<eject<< "\n";			
			#endif
			//close ini file
			inifile.Reset();
			//Run the program
			STARTUPINFO si;
			ZeroMemory(&si, sizeof(si));
			si.cb = sizeof(si);
			PROCESS_INFORMATION pi;
			
			if (CreateProcess(NULL, DrvIni, NULL, NULL, TRUE, DETACHED_PROCESS, NULL, NULL, &si, &pi))
			{
				if (eject)
				{
					#ifdef _DEBUG
					debugwindow<<"Waiting for process to terminate...\n";			
					#endif
					WaitForInputIdle(pi.hProcess, INFINITE);
					WaitForSingleObject(pi.hProcess, INFINITE);
					#ifdef _DEBUG
					debugwindow<<"Process terminated!\n";			
					#endif
				}
				CloseHandle(pi.hThread);
				CloseHandle(pi.hProcess);			
				//if (eject) RemoveDriveByLetter ('g');
				Sleep(1000);
				if (eject) RemoveDriveByLetter (cmdLine.GetArgument("-d",0)[0]);
			}			
			else //in case the exe specified in u3-autorun.ini can't be started or doesn't exist
			{
				CloseHandle(pi.hThread);
				CloseHandle(pi.hProcess);
			}

		}		
		SelfDelete();
	}
	//we shouldn't jump directly here at runtime, but if we do, we were called without a commanline.  This would be useless
	#ifdef _DEBUG	
	debugwindow << "Execution completed.";
	debugwindow.Close();
	#endif
	return 0;
}