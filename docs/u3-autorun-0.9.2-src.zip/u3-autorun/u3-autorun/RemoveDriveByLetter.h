//int RemoveDriveByLetter(char argv[]);
int RemoveDriveByLetter(char DriveLetter);