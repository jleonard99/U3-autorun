// [AJW] Best reference claiming original authorship I could find is by Tony Varnas on CodeGuru:
// http://www.codeguru.com/cpp/w-p/win32/article.php/c4533/

// According to their terms of usage, this code is perfectly acceptible to use here, and the MIT license should be compatible.[/AJW]

#include "stdafx.h"
#include <windows.h>
#include <shellapi.h>

bool SelfDelete()
{
	SHELLEXECUTEINFO sei;

	TCHAR szModule [MAX_PATH],
	szComspec[MAX_PATH],
	szParams [MAX_PATH];

	// get file path names
	if((GetModuleFileName(0,szModule,MAX_PATH)!=0) &&
	(GetShortPathName(szModule,szModule,MAX_PATH)!=0) &&
	(GetEnvironmentVariable("COMSPEC",szComspec,MAX_PATH)!=0))
	{
		// create comspec parameters
		lstrcpy(szParams,"/c del "); // run a single command to...
		lstrcat(szParams, szModule); // del(ete) module file and...
		lstrcat(szParams, " > nul"); // output results to nowhere

		// set struct members
		sei.cbSize = sizeof(sei);
		sei.hwnd = 0;
		sei.lpVerb = "Open";
		sei.lpFile= szComspec;
		sei.lpParameters = szParams;
		sei.lpDirectory = 0;
		sei.nShow = SW_HIDE;
		sei.fMask = SEE_MASK_NOCLOSEPROCESS;

		// give all CPU cycles to current process
		SetPriorityClass(GetCurrentProcess(),REALTIME_PRIORITY_CLASS);
		SetThreadPriority(GetCurrentThread(),THREAD_PRIORITY_TIME_CRITICAL);

		// execute command shell (creates new process)
		if(ShellExecuteEx(&sei))
		{
			// freeze command shell process (to give time to our process to finish)
			SetPriorityClass(sei.hProcess,IDLE_PRIORITY_CLASS);
			SetProcessPriorityBoost(sei.hProcess,TRUE);

			return TRUE;
		}
		else
		{
			// otherwise, restore normal priority
			SetPriorityClass(GetCurrentProcess(),NORMAL_PRIORITY_CLASS);
			SetThreadPriority(GetCurrentThread(),THREAD_PRIORITY_NORMAL);
		}
	}
	return FALSE;
}